あなたはこのアイデアの実装担当エージェントです。要件定義、仕様、設計、MVP実装、検証まで、この開発パックに沿って進めてください。

## 対象アイデア

- 親分類: Apps
- 領域: ProjectManagement
- No.: 4
- 分野: 品質・検証証跡
- アイデア: 品質ルール・手動検証・検証ログ収集
- リポジトリ名: quality-rule-verification-log-collector

## 元アイデア

- 概要: 品質ルール、手動検証シート、テスト結果、スクリーンショット、ビルドログ、Issueコメントを作業単位で集める。
- 課題: 自動検査、目視確認、レビュー対応、完了報告が分かれると、何を確認したか追跡しづらい。
- 類似サービス・アプリ: GitHub Actions, Allure, TestRail, Linear, Codex
- 差別化ポイント: Issueクローズやリリース判断に使える証跡として、自動検査と人間確認を同じ成果物に残す。

## 最初に行うこと

1. このZIP内の `01_REQUIREMENTS.md`、`02_SPECIFICATION.md`、`03_DESIGN.md` を読む。
2. 実装前に未決事項を洗い出す。
3. 既存リポジトリがある場合は、先に README、docs、Issue、テスト、現在のアーキテクチャを確認する。
4. 新規リポジトリの場合は、`04_IMPLEMENTATION_PLAN.md` のMVPから開始する。
5. 実装前に、プラットフォーム、保存方式、主要ユーザーフロー、検証方法を明記する。

## 領域別の重点事項

- 主要ユーザー、ローカル保存、権限、バックアップ、外部API境界を明確にする。
- 入力から確認、履歴、出力までの一連の流れを設計する。
- 日常利用フロー、データ復旧、プライバシーに関わる挙動を検証する。

## Done Means

- The MVP works.
- The main flow has been manually verified.
- Test or verification steps are repeatable.
- README or usage notes are updated.
- Remaining work is captured in release checklist or issues.
