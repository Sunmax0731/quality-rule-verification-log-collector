# 品質ルール・手動検証・検証ログ収集 開発パック

| 項目 | 内容 |
| --- | --- |
| 領域 | ProjectManagement |
| No. | 4 |
| 分野 | 品質・検証証跡 |
| アイデア | 品質ルール・手動検証・検証ログ収集 |
| リポジトリ名 | quality-rule-verification-log-collector |
| 概要 | 品質ルール、手動検証シート、テスト結果、スクリーンショット、ビルドログ、Issueコメントを作業単位で集める。 |
| 課題 | 自動検査、目視確認、レビュー対応、完了報告が分かれると、何を確認したか追跡しづらい。 |
| 類似サービス・アプリ | GitHub Actions, Allure, TestRail, Linear, Codex |
| 差別化ポイント | Issueクローズやリリース判断に使える証跡として、自動検査と人間確認を同じ成果物に残す。 |

## 目的

このZIPには、`ProjectManagement` 領域のアイデア `品質ルール・手動検証・検証ログ収集` を実装可能なプロジェクトへ落とし込むための初期ドキュメントが含まれています。

## 含まれるファイル

- START_PROMPT.md
- README.md
- 01_REQUIREMENTS.md
- 02_SPECIFICATION.md
- 03_DESIGN.md
- 04_IMPLEMENTATION_PLAN.md
- 05_TEST_PLAN.md
- 06_RELEASE_CHECKLIST.md
- metadata.json

## 使い方

1. Codexまたは他のコーディングエージェントへの最初のプロンプトとして `START_PROMPT.md` を使用する。
2. 実装前に要件、仕様、設計を確認する。
3. MVPを実装し、テスト計画に沿って検証する。
